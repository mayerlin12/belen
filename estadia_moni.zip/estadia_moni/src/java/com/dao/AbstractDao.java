package com.dao;


import com.util.ContextPathServer;
import java.io.File;
import java.io.InputStream;
import java.sql.Connection;
import java.util.Properties;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author skand
 */
public abstract class AbstractDao {
    
    protected String driver = "", dbname = "", usr = "", pass = "", url = "";
    File path;
    ContextPathServer cps = new ContextPathServer();
    String realContextPath = cps.getContextPath();

    protected AbstractDao() {
        try {
            Properties props = new Properties();
            InputStream in = new java.io.FileInputStream(realContextPath + "WEB-INF/classes/com/dao/conection.props");
            props.load(in);
            in.close();
            driver = props.getProperty("driver");
            url = props.getProperty("url");
            usr = props.getProperty("usr");
            pass = props.getProperty("pass");

        } catch (Exception e) {
            System.out.println("Error en ConexionBD:" + e);
            e.printStackTrace();
        }

    }

    public abstract Connection getConnection();

    public abstract boolean testConnection();
}
