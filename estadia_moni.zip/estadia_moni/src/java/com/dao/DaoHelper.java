/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Hashtable;

/**
 *
 * @author skand
 */
public class DaoHelper extends BDatos {
    
    private Connection conn;
        public ArrayList getResultTable(String query){
        
        Hashtable hash = new Hashtable(0);
        
        ArrayList arrayResult = new ArrayList(0);
        arrayResult.clear();
        String elemento = "", Columna;
        try{
            conn = getConnection();
            Statement stm = conn.createStatement();
            ResultSet rst = stm.executeQuery(query);
            ResultSetMetaData rsmd = rst.getMetaData();

            while(rst.next()){
                for(int i = 1;i<= rsmd.getColumnCount();i++){
                    Columna = rsmd.getColumnName(i);
                    elemento = rst.getString(Columna);
                    if(elemento != null){
                        hash.put(Columna, elemento);
                    }else{
                        hash.put(Columna, "");
                    }
                }
                arrayResult.add(new Hashtable(hash));
                hash.clear();
            }
            
            
        }catch(Exception ex){
            System.out.println(ex.toString());
            arrayResult.clear();
        }finally{
            closeConnection(conn);
        }
        return arrayResult;
    }
    
}
