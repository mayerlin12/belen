/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.util;

/**
 *
 * @author skand
 */
public class consultassql {
    public static String donacioones (){
        return "select distinct cast(d_fecha as date) fecha, d_abo grupo, d_rh rh, p_numero folio, case when u_id is not null then 'Exitosa' else 'No exitosa' end estatus from \"Donaciones\" d inner join \"Unidades\" u on d.d_id = u.u_don_id inner join \"Poblacion\" po on d.d_pob_id = po.p_id";
    }
    public static String unidades (){
        return "select cast(u_fecha_ingreso as date) fecha1, cast(u_fecha_vence as date) fecha2,u_hem_id hemo,h_nombre nombre, u_abo grupo, u_rh rh, u_irradiado irradiado, u_filtrado filtrado, u_lavado lavado, u_centrifugado centrifugado, case when u_estado=20 then cast(u_fecha_salida as date)  when u_estado= 25 then cast(u_fecha_descarte as date) end fecha_salida from \"Unidades\" u inner join \"Hemocomponentes\" h on u_hem_id = h.h_id order by u_fecha_ingreso desc limit 1000";
    }
}
